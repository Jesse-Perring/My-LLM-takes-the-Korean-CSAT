import sys
import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import dotenv
dotenv.load_dotenv(os.path.join(PROJECT_ROOT, '.env'))

import importlib
import Utils.problem_loader as problem_loader
import Utils.scoring as scoring
import Utils.result_writer as result_writer
import os


# ===================================================

MODEL_NAME = "GPT4o"
PROMPTING_METHOD = "ZeroShot"
DATA_FILENAME = "202511_en.json"

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../data/json'))
JSON_PATH = os.path.join(DATA_DIR, DATA_FILENAME)

def dynamic_import(module_path: str, func_name: str):
    module = importlib.import_module(module_path)
    return getattr(module, func_name)

def main() -> None:

    problems = problem_loader.load_problems(JSON_PATH)

    # results: [{'is_correct': bool, 'score': int, 'category': str}]
    # model_outputs: [str]
    per_problem_results = []
    results = []
    model_outputs = []

 
    model_func = dynamic_import(f"Models.{MODEL_NAME}", "call_model")

    prompt_func = dynamic_import(f"Core.Prompting.{PROMPTING_METHOD}", f"run_{PROMPTING_METHOD.lower()}")

    for problem in problem_loader.crop_problems(problems):

        model_output = prompt_func(problem, model_func)


        model_outputs.append(model_output)


        is_correct = scoring.judge_by_llm(model_func, problem, model_output)


        result_writer.append_result(results, per_problem_results, problem, is_correct)

    text_lines = result_writer.write_result_lines(per_problem_results, results, problems, model_outputs)
    

    result_writer.save_results(
        text_lines, MODEL_NAME, PROMPTING_METHOD, DATA_FILENAME
    )

if __name__ == "__main__":
    main()